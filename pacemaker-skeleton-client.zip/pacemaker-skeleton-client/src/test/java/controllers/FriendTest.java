package controllers;

import static org.junit.Assert.*;
import java.util.Collection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import models.Friend;
import static models.Fixtures.Friends;

public class FriendTest {

  PacemakerAPI pacemaker = new PacemakerAPI("https://nameless-citadel-51826.herokuapp.com");
  Friend homer = new Friend("homer", "simpson", "homer@simpson.com");

  @Before
  public void setup() {
    pacemaker.deleteFriend();
  }

  @After
  public void tearDown() {
  }

  @Test
  public void testCreateFriend() {
    Friend Friend = pacemaker.createFriend(homer.firstname, homer.lastname, homer.email);
    assertEquals(Friend, homer);

  }

  @Test
  public void testCreateFriends() {
    Friends.forEach(
        Friend -> pacemaker.createFriend(Friend.firstname, Friend.lastname, Friend.email));
    Collection<Friend> returnedFriends = pacemaker.getFriends();
    assertEquals(Friends.size(), returnedFriends.size());
  }
}