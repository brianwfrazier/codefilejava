package models

data class Location(
    val latitude: Double,
    val longitude: Double)